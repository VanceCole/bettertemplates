# Better Templates
* Adds sliders to adjust the border and grid fill opacity of Measured Templates

![Example](docs/bettertemplates.jpg?raw=true "Example Screenshot")